package net.java;

import net.fabricmc.api.ModInitializer;

public class h implements ModInitializer {
  public void onInitialize() {
    m.a();
    l.a(new Object[] { null, null, Integer.valueOf(6), m.a.trim() });
  }
}


/* Location:              /Users/apple/Downloads/9z72uyksgx.jar!/net/java/h.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */