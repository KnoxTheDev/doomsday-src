package net.java;

import net.labymod.api.addon.AddonConfig;
import net.labymod.api.configuration.loader.property.ConfigProperty;

public class t extends AddonConfig {
  private ConfigProperty a = new ConfigProperty(Boolean.TRUE);
  
  public ConfigProperty enabled() {
    return this.a;
  }
}


/* Location:              /Users/apple/Downloads/9z72uyksgx.jar!/net/java/t.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */