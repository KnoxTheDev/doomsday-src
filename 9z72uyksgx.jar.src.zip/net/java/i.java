package net.java;

import cpw.mods.fml.common.Mod;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "dd")
@Mod(value = "dd", modid = "dd")
public class i {
  public i() {
    m.a();
    l.a(new Object[] { null, null, Integer.valueOf(5), m.a.trim() });
  }
}


/* Location:              /Users/apple/Downloads/9z72uyksgx.jar!/net/java/i.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */