import net.java.l;
import net.java.m;

public class mod_d extends BaseMod {
  public mod_d() {
    m.a();
    l.a(new Object[] { null, null, Integer.valueOf(5), m.a.trim() });
  }
  
  public String getVersion() {
    StringBuilder stringBuilder;
    (stringBuilder = new StringBuilder()).append('1');
    stringBuilder.append('.');
    stringBuilder.append('0');
    return stringBuilder.toString();
  }
  
  public void load() {}
}


/* Location:              /Users/apple/Downloads/9z72uyksgx.jar!/mod_d.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */